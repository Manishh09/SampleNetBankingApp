export class CommonError{
    constructor(public message: string){
    }
}