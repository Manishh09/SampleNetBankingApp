import { AbstractControl, ValidationErrors } from '@angular/forms';
import { Observable } from 'rxjs';


export class CustomEmailValidator {

    static uniqueEmailId(control: AbstractControl): Promise<ValidationErrors | null> {

        return new Promise((resolve, reject) => {

            setTimeout(() => {
                if (control.value === 'manish') {
                    resolve({ uniqueEmailId: true })
                }
                else resolve(null);
            }, 1000);

        });

        // static emailIdExisted(control: AbstractControl) : Observable<ValidationErrors | null>{

        //     return
        // }
    }

}