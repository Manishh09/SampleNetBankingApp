export interface CustomerData{
    email:any,
    password:any,
    confirmpassword: any 
}